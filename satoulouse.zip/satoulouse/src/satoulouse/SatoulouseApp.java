/*
 * SatoulouseApp.java
 */

package satoulouse;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jdesktop.application.Application;
import org.jdesktop.application.SingleFrameApplication;

/**
 * The main class of the application.
 */
public class SatoulouseApp extends SingleFrameApplication {

    private static void commandLineCheckArrayListOfFormulas(ArrayList<String> formulas) {
            SATSolverSAT4J solver = new SATSolverSAT4J();
            System.out.println("On envoie au solveur");
            try
             {
                solver.addFormula(new FormulaForSAT4J(new Formula("top")));
                solver.addFormula(new FormulaForSAT4J(new Formula("(not bottom)")));
                 
                 
                for(String s : formulas)
                     solver.addFormula(new FormulaForSAT4J(new Formula(s)));
            } catch (Exception ex) {
                SchemeWithKawa.restart();
                return;
            }
            Chronometre.printDuree();
            
            ArrayList<String> propositionsVraies;
            try
             {
                    propositionsVraies = solver.isSAT(); // this?
            } catch (Exception ex) {
                SchemeWithKawa.restart();
                System.out.println("error from the solver: ");
                System.out.println(ex);
                return;
            }
        
        
            if(propositionsVraies != null)
            {
                System.out.println("satisfiable. Here is a valuation: ");
                System.out.println(propositionsVraies);
                Chronometre.printDuree();
            }
            else
            {
                System.out.println("unsatisfiable");
                Chronometre.printDuree();
            }
    }

    private static void commandLineCheckFromFile(String filename) {
        ArrayList<String> s;
        try {
            s = TextFile.lire_dans_un_fichier_lignes(filename); // TODO add your handling code here:
            
            commandLineCheckArrayListOfFormulas(s);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(SatoulouseView.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(SatoulouseView.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * At startup create and show the main frame of the application.
     */
    @Override protected void startup() {
        show(new SatoulouseView(this));
    }

    /**
     * This method is to initialize the specified window by injecting resources.
     * Windows shown in our application come fully initialized from the GUI
     * builder, so this additional configuration is not needed.
     * @param root 
     */
    @Override protected void configureWindow(java.awt.Window root) {
    }

    /**
     * A convenient static getter for the application instance.
     * @return the instance of SatoulouseApp
     */
    public static SatoulouseApp getApplication() {
        return Application.getInstance(SatoulouseApp.class);
    }

    /**
     * Main method launching the application.
     * @param args 
     */
    public static void main(String[] args) {
        if(args.length == 0)
              launch(SatoulouseApp.class, args);
        else
        {
            if(args[0].equals("-file"))
            {
                commandLineCheckFromFile(args[1]);
            }
            else
            {
                ArrayList<String> formulas = new ArrayList<String>();
                formulas.addAll(Arrays.asList(args));
                commandLineCheckArrayListOfFormulas(formulas);
            }
        }
    }
}
