/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package satoulouse;

/**
 *
 * @author proprietaire
 */
public class Help {
    static public void show(String what)
    {
        DialogHelp dh = new DialogHelp(null, true);
        dh.page_show(what);
        dh.setSize(1000,700);       //C.L.     26/05/11
        dh.setTitle("Aide...");     //C.L.
        dh.setResizable(true);     //C.L.
        dh.setVisible(true);
    }
}
